package com.utn.tp1jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpJPApplicationTests {

	@Test
	void contextLoads() {
	}

}
